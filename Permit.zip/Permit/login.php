


<?php
session_start();
include('includes/config.php');
if (isset($_POST['signin'])) {
  $email = $_POST['email'];
  $password = md5($_POST['password']);

  $sql = "SELECT * FROM users where email='$email' AND password='$password'";
  $query = mysqli_query($conn, $sql);
  $count = mysqli_num_rows($query);
  if ($count > 0) {
    while ($row = mysqli_fetch_assoc($query)) {
      if ($row['role'] == 'admin') {
        $_SESSION['alogin'] = $row['id'];
        $_SESSION['arole'] = $row['Department'];
        echo "<script type='text/javascript'> document.location = 'admin/admin_dashboard.php'; </script>";
      } elseif ($row['role'] == 'client') {
        $_SESSION['alogin'] = $row['id'];
        $_SESSION['arole'] = $row['Department'];
        echo "<script type='text/javascript'> document.location = 'client/index.php'; </script>";
      } elseif ($row['role'] == 'authorising') {
        $_SESSION['alogin'] = $row['id'];
        $_SESSION['arole'] = $row['Department'];
        echo "<script type='text/javascript'> document.location = 'authorising/index.php'; </script>";
      } elseif ($row['role'] == 'receiving') {
        $_SESSION['alogin'] = $row['id'];
        $_SESSION['arole'] = $row['Department'];
        echo "<script type='text/javascript'> document.location = 'receiving/index.php'; </script>";
      } else {
        $_SESSION['alogin'] = $row['id'];
        $_SESSION['arole'] = $row['Department'];
        echo "<script type='text/javascript'> document.location = 'issuing/index.php'; </script>";
      }
    }
  } else {

    echo "<script>alert('Invalid Details');</script>";
  }
}
//$_SESSION['alogin'] = $_POST['email'];
//echo "<script type='text/javascript'> document.location = 'changepassword.php'; </script>";
?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Login - Production Analysis Management Hackathon - ABSA</title>
    <link rel="shortcut icon" href="favicon.png" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="fonts/flaticon.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style-2.css" />
  </head>
  <body>
    <section class="fxt-template-animation fxt-template-layout25">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 col-12 fxt-bg-gradient">
            <div class="fxt-header">
              <div class="fxt-top-content">
                <div class="fxt-transformY-50 fxt-transition-delay-1">
                  <a href="index.php" class="fxt-logo"
                    ><img src="images/ABSA2.jpg" alt="Logo" width="150"
                  /></a>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-2">
                  <h1>Welcome To ABSA Hackathon</h1>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-3">
                  <p>Production Analysis Management portal</p>
                </div>
              </div>
              <div class="fxt-bottom-content">
                <div class="fxt-transformY-50 fxt-transition-delay-11">
                  <p>
                    Don't have an account?<a
                      href="register.php"
                      class="switcher-text inline-text"
                      >Register</a
                    >
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-12 fxt-bg-color">
            <div class="fxt-content">
              <div class="fxt-form">
                <div class="fxt-transformY-50 fxt-transition-delay-12">
                  <h2>Login</h2>
                </div>
                <form method="POST">
                  <div class="form-group"></div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="email"
                        class="form-control"
                        name="email"
                        placeholder="Email Address"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-15">
                      <input
                        id="password"
                        type="password"
                        class="form-control"
                        name="password"
                        placeholder="********"
                        required="required"
                      />
                      <i
                        toggle="#password"
                        class="fa fa-fw fa-eye toggle-password field-icon"
                      ></i>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-17">
                      <button type="submit" class="fxt-btn-fill" name="signin">Login</button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <!-- Imagesloaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- Validator js -->
    <script src="js/validator.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>
  </body>
</html>
