<?php include('includes/header.php') ?>
<?php include('../includes/session.php') ?>


<?php
if (isset($_POST['payment'])) {

    $payment = $_POST['payment'];


    $result = mysqli_query($conn, "update import set payment='$payment' where id='$session_id'         
		");
    if ($result) {
        echo "<script>alert('Payment  Successfully Made');</script>";
        echo "<script type='text/javascript'> document.location = 'import.php'; </script>";
    } else {
        die(mysqli_error());
    }
}

?>

<!DOCTYPE html>




<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Payment Form</title>
    <link rel="stylesheet" href="../includes/style.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <div class="container">
        <h1>Confirm Your Payment</h1>
        <form action="" method="post">
            <div class="first-row">
                <div class="owner">
                    <h3>Owner</h3>
                    <div class="input-field">
                        <input type="text" required="true">
                    </div>
                </div>
                <div class="cvv">
                    <h3>CVV</h3>
                    <div class="input-field">
                        <input type="password" minlength="3" maxlength="3" required="true">
                    </div>
                </div>
            </div>
            <div class="second-row">
                <div class="card-number">
                    <h3>Card Number</h3>
                    <div class="input-field">
                        <input type="text" name="payment" minlength="16" maxlength="16" required="true">
                    </div>
                </div>
            </div>
            <div class="third-row">
                <h3>Expiry Date</h3>
                <div class="selection">
                    <div class="date">
                        <select name="months" id="months" required="true">
                            <option value="Jan">Jan</option>
                            <option value="Feb">Feb</option>
                            <option value="Mar">Mar</option>
                            <option value="Apr">Apr</option>
                            <option value="May">May</option>
                            <option value="Jun">Jun</option>
                            <option value="Jul">Jul</option>
                            <option value="Aug">Aug</option>
                            <option value="Sep">Sep</option>
                            <option value="Oct">Oct</option>
                            <option value="Nov">Nov</option>
                            <option value="Dec">Dec</option>
                        </select>
                        <select name="years" id="years">
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
                            <option value="2015">2015</option>
                        </select>
                    </div>
                    <div class="cards">
                        <img src="../images/mc.png" alt="">
                        <img src="../images/vi.png" alt="">
                        <img src="../images/pp.png" alt="">
                    </div>
                </div>
            </div>

            <div class="modal-footer justify-content-center">
                <button class="btn btn-primary" name="payment" id="" data-toggle="modal">Pay</button>
            </div>
        </form>
    </div>
</body>

</html>