<?php include('includes/header.php') ?>
<?php include('../includes/session.php') ?>
<?php
if (isset($_POST['register'])) {
    $id = $session_id;
    $cname = $_POST['cname'];
    $registered = $_POST['registered'];
    $salvage = $_POST['salvage'];
    $location = $_POST['location'];
    $postal = $_POST['postal'];
    $tell = $_POST['tell'];
    $email = $_POST['email'];
    //$prc = $_POST['prc'];
    $date = $_POST['date'];
    $astatus = 0;
    $isread = 0;
    $ref = mt_rand(100000000, 999999999);








    $sql = "INSERT INTO forma(id,cname,registered,salvage,location,postal,tell,email,date,astatus,isread,ref) VALUES(:id,:cname,:registered,:salvage,:location,:postal,:tell,:email,:date,:astatus,:isread,:ref)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_STR);

    $query->bindParam(':cname', $cname, PDO::PARAM_STR);
    $query->bindParam(':registered', $registered, PDO::PARAM_STR);
    $query->bindParam(':salvage', $salvage, PDO::PARAM_STR);
    $query->bindParam(':location', $location, PDO::PARAM_STR);
    $query->bindParam(':postal', $postal, PDO::PARAM_STR);
    $query->bindParam(':tell', $tell, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':date', $date, PDO::PARAM_STR);
    $query->bindParam(':astatus', $astatus, PDO::PARAM_STR);
    $query->bindParam(':isread', $isread, PDO::PARAM_STR);
    $query->bindParam(':ref', $ref, PDO::PARAM_STR);



    $query->execute();
    $lastInsertId = $dbh->lastInsertId();
    if ($lastInsertId) {
        echo "<script>alert('Permit Application was Not  successful.');</script>";
        echo "<script type='text/javascript'> document.location = 'import.php'; </script>";
    } else {
        //echo "<script>alert('Something went wrong. Please try again');</script>";
        echo "<script>alert('Permit Application was successful.');</script>";
        echo "<script type='text/javascript'> document.location = 'import.php'; </script>";
    }
}



?>

<body>
    <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo"><img src="../vendors/images/deskapp-logo-svg.png" alt=""></div>
            <div class='loader-progress' id="progress_div">
                <div class='bar' id='bar1'></div>
            </div>
            <div class='percent' id='percent1'>0%</div>
            <div class="loading-text">
                Loading...
            </div>
        </div>
    </div>

    <?php include('includes/navbar.php') ?>

    <?php include('includes/right_sidebar.php') ?>

    <?php include('includes/left_sidebar.php') ?>

    <div class="mobile-menu-overlay"></div>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pb-20">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Company Registration </h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Register</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>

                <div style="margin-left: 50px; margin-right: 50px;" class="pd-20 card-box mb-30">
                    <div class="clearfix">
                        <div class="pull-left">
                            <h4 class="text-blue h4">Registration Form</h4>
                            <p class="mb-20"></p>
                        </div>
                    </div>
                    <div class="wizard-content">
                        <form method="post" action="">
                            <section>

                                <?php if ($role = 'client') : ?>
                                    <?php $query = mysqli_query($conn, "select * from users where id = '$session_id'") or die(mysqli_error());
                                    $row = mysqli_fetch_array($query);
                                    ?>






                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Company Name </label>
                                                <input name="cname" type="text" class="form-control wizard-required" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Name of Registered Business/Company </label>
                                                <input name="registered" type="text" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">

                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Salvage Yards license no</label>
                                                <input name="salvage" type="text" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Physical location of Salvage Yard</label>
                                                <input name="location" type="text" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>

                                    <?php endif ?>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Postal Address</Address></label>
                                                <input name="postal" type="text" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Telephone No.</label>
                                                <input name="tell" type="text" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Email Address</label>
                                                <input name="email" type="email" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Application Date :</label>
                                                <input name="date" type="text" class="form-control date-picker" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>
                                    <h5 class="text-blue h5">Applicant is required to submit certified documents of Copy of Salvage yards license, BURS Tax Clearance certificate ,
                                        I.D (Omang) /Passport of Managing Director, Copies of Registration of Incorporation or Business Registration Certificate,
                                        Copies of Shareholding certificates in addition to this form as a file/folder.</h5>


                                    <!--     <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class="form-group">
                                                <label>Upload File</label>
                                                <input name="file" type="file" class="form-control" required="true" autocomplete="off">
                                            </div>
                                        </div>
                                    </div>

                                -->

                                    <div class="row">

                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b></b></label>
                                                <div class="modal-footer justify-content-center">
                                                    <button class="btn btn-primary" name="register" id="register" data-toggle="modal">Register&nbsp;</button>
                                                </div>
                                            </div>
                                        </div>




                                    </div>
                            </section>
                        </form>
                    </div>
                </div>

            </div>
            <?php include('includes/footer.php'); ?>
        </div>
    </div>
    <!-- js -->
    <?php include('includes/scripts.php') ?>
</body>

</html>