

<?php include('includes/header.php') ?>
<?php include('../includes/session.php') ?>

  <?php include('includes/navbar.php') ?>

    <?php include('includes/right_sidebar.php') ?>

    <?php include('includes/left_sidebar.php') ?>

<?php




$file_name = 'rebate.jpg';
$font = realpath('sans.ttf');
$uid = $session_id;
$sql = "SELECT * from rebate where id='$uid'";



foreach ($dbh->query($sql) as $row) {


  // $QR = imagecreatefromstring(file_get_contents("https://chart.googleapis.com/chart?cht=qr&choe=UTF-8&chs=150x150&chl=" . urlencode($row->id)));

  imagecopyresampled($img_source, $QR, 160, 690, 0, 0, 150, 150, 150, 150);
  //https: //image-charts.com/chart?chs=150x150&cht=qr&chl=Hello%20world&choe=UTF-8
  //name

  $x = 160;
  $y = 690;
  $img_source = imagecreatefromjpeg($file_name);
  $text_colour = imagecolorallocate($img_source, 51, 51, 102);
  // ImageString($img_source, $font, $x, $y, $row['HusbandName'], $text_colour);
  imagettftext($img_source, 38, 0, 100, 100, $color, $font, $row['cname']);
  imagettftext($img_source, 38, 0, 160, 690, $color, $font, $row['purpose']);
  imagettftext($img_source, 38, 0, 1100, 690, $color, $font, $row['descrip']);
  //  imagettftext($img_source, 38, 0, 760, 850, $color, $font, $row['hsvillage']);
  //  imagettftext($img_source, 38, 0, 1510, 850, $color, $font, $row['DateOfMarriage']);
  //  imagettftext($img_source, 38, 0, 220, 990, $color, $font, $row['']);
  // imagettftext($img_source, 38, 0, 1100, 985, $color, $font, $row['WitnessNamefirst']);
  // imagettftext($img_source, 38, 0, 150, 1110, $color, $font, $row['WitnessNamesec']);





  imagejpeg($img_source, "certificate/$row[cname].jpg");
  echo "Certificate Generated Succesfully";



  // imagejpeg($img_source);
  imagedestroy($img_source);
}
