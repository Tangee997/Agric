<div class="footer-wrap pd-20 mb-20 card-box">
	Production Analysis Management System <a href="#" target="_blank"><span>developed by </span>Elite Minds</a>
</div>