<?php include('includes/header.php') ?>
<?php include('../includes/session.php') ?>
<?php
if (isset($_POST['formb'])) {
    $id = $session_id;
    $name = $_POST['name'];
    $lastname = $_POST['lastname'];
    $registered = $_POST['registered'];
    $slicence = $_POST['slicence'];
    $postal = $_POST['postal'];
    $tell = $_POST['tell'];
    $email = $_POST['email'];
    $physical = $_POST['physical'];
    $proposeddate = $_POST['proposeddate'];
    $portexit = $_POST['portexit'];
    $regtruck = $_POST['regtruck'];
    $destination = $_POST['destination'];
    $quantity = $_POST['quantity'];
    $value = $_POST['value'];
    $exportto = $_POST['exportto'];
    $dest = $_POST['dest'];
    $descrip = $_POST['descrip'];
    $tariff = $_POST['tariff'];
    $submission = $_POST['submission'];
    $astatus = 0;
    $isread = 0;
    $ref = mt_rand(100000000, 999999999);






    $sql = "INSERT INTO formb(id,name,lastname,registered,slicence,postal,tell,email,physical,proposeddate,portexit,regtruck,destination,quantity,value,exportto,dest,descrip,tariff,submission,astatus,isread,ref) VALUES(:id,:name,:lastname,:registered,:slicence,:postal,:tell,:email,:physical,:proposeddate,:portexit,:regtruck,:destination,:quantity,:value,:exportto,:dest,:descrip,:tariff,:submission,:astatus,:isread,:ref)";
    $query = $dbh->prepare($sql);
    $query->bindParam(':id', $id, PDO::PARAM_STR);
    $query->bindParam(':name', $name, PDO::PARAM_STR);
    $query->bindParam(':lastname', $lastname, PDO::PARAM_STR);
    $query->bindParam(':registered', $registered, PDO::PARAM_STR);
    $query->bindParam(':slicence', $slicence, PDO::PARAM_STR);
    $query->bindParam(':postal', $postal, PDO::PARAM_STR);
    $query->bindParam(':tell', $tell, PDO::PARAM_STR);
    $query->bindParam(':email', $email, PDO::PARAM_STR);
    $query->bindParam(':physical', $physical, PDO::PARAM_STR);
    $query->bindParam(':proposeddate', $proposeddate, PDO::PARAM_STR);
    $query->bindParam(':portexit', $portexit, PDO::PARAM_STR);
    $query->bindParam(':regtruck', $regtruck, PDO::PARAM_STR);
    $query->bindParam(':destination', $destination, PDO::PARAM_STR);
    $query->bindParam(':quantity', $quantity, PDO::PARAM_STR);
    $query->bindParam(':value', $value, PDO::PARAM_STR);
    $query->bindParam(':exportto', $exportto, PDO::PARAM_STR);
    $query->bindParam(':dest', $dest, PDO::PARAM_STR);
    $query->bindParam(':descrip', $descrip, PDO::PARAM_STR);
    $query->bindParam(':tariff', $tariff, PDO::PARAM_STR);
    $query->bindParam(':submission', $submission, PDO::PARAM_STR);

    $query->bindParam(':astatus', $astatus, PDO::PARAM_STR);
    $query->bindParam(':isread', $isread, PDO::PARAM_STR);
    $query->bindParam(':ref', $ref, PDO::PARAM_STR);

    $query->execute();
    $lastInsertId = $dbh->lastInsertId();
    if ($lastInsertId) {
        echo "<script>alert('Permit Application was Not  successful.');</script>";
        echo "<script type='text/javascript'> document.location = 'export.php'; </script>";
    } else {
        //echo "<script>alert('Something went wrong. Please try again');</script>";
        echo "<script>alert('Permit Application was successful. You Will Now Pay P1000.00');</script>";
        echo "<script type='text/javascript'> document.location = 'payments.php'; </script>";
    }
}



?>

<body>
    <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo"><img src="../vendors/images/deskapp-logo-svg.png" alt=""></div>
            <div class='loader-progress' id="progress_div">
                <div class='bar' id='bar1'></div>
            </div>
            <div class='percent' id='percent1'>0%</div>
            <div class="loading-text">
                Loading...
            </div>
        </div>
    </div>

    <?php include('includes/navbar.php') ?>

    <?php include('includes/right_sidebar.php') ?>

    <?php include('includes/left_sidebar.php') ?>

    <div class="mobile-menu-overlay"></div>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pb-20">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>Import Permit</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="index.php">Dashboard</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Your Import Permit</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>

                <div style="margin-left: 50px; margin-right: 50px;" class="pd-20 card-box mb-30">
                    <div class="clearfix">
                        <div class="pull-left">

                            <p class="mb-20"></p>
                        </div>
                    </div>
                    <div class="wizard-content">
                        <form method="post" action="">
                            <section>

                                <?php if ($role = 'client') : ?>
                                    <?php $query = mysqli_query($conn, "select * from users   where id = '$session_id'") or die(mysqli_error());
                                    $row = mysqli_fetch_array($query);
                                    ?>

                                    <h4 class="text-blue h4">IMPORT PERMIT</h4>

                                    <div class="col-md-6 col-sm-12">
                                        <div class="form-group">
                                            <ol>
                                                <li class="">First Name : <?php echo $row['name']; ?></li>
                                                <br>
                                                <li class="">Last Name : <?php echo $row['surname']; ?></li>
                                            </ol>
                                        </div>
                                    </div>
                    </div>

                    <?php if ($role = 'client') : ?>
                        <?php $query = mysqli_query($conn, "select * from import where id = '$session_id'") or die(mysqli_error());
                                        $row = mysqli_fetch_array($query);
                        ?>
                        <div class="col-md-6 col-sm-12">
                            <div class="form-group">
                                <ol>
                                    <li class=""> Name of Registered Business/Company : <?php echo $row['cname']; ?></li>
                                    <br>
                                    <li class=""> Importing From/Country : <?php echo $row['importfrom']; ?></li>
                                    <br>
                                    <li class=""> Supplier Name : <?php echo $row['sname']; ?></li>
                                    <br>
                                    <li class=""> Purpose Of Goods : <?php echo $row['purpose']; ?></li>
                                    <br>
                                    <li class=""> Decription : <?php echo $row['descrip']; ?></li>
                                    <br>
                                    <li class=""> Quantity Of Goods : <?php echo $row['qty']; ?></li>
                                    <br>
                                    <li class=""> Price/unit : <?php echo $row['prc']; ?></li>
                                    <br>
                                    <li class=""> Total Amount : <?php echo $row['tamount']; ?></li>
                                    <br>
                                    <li class=""> Date Submitted : <?php echo $row['date']; ?></li>

                                </ol>
                            </div>
                        </div>

                </div>
            <?php endif ?>
            </div>


        <?php endif ?>
        </section>
        </form>


        </div>
    </div>

    </div>
    <?php include('includes/footer.php'); ?>
    </div>
    </div>
    <!-- js -->
    <?php include('includes/scripts.php') ?>
</body>

</html>