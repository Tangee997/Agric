<!DOCTYPE html>
<html lang="en" xmlns="http://www.w3.org/1999/xhtml">

<head>
  <title>Production Analysis Management System - ABSA HACKTHON</title>
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <meta name="HandheldFriendly" content="true" />
  <meta name="author" content="beshleyua" />
  <meta name="description" content="Creative Agency Portfolio HTML5 Template. Best suited for Portfolio, Agency, Photography, Showcases." />

  <!-- fontawesome CSS -->
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.0/css/all.css" />

  <!-- fonts googleapis CSS -->
  <link rel="preconnect" href="https://fonts.gstatic.com" />
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Yeseva+One&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Mr+De+Haviland&display=swap" rel="stylesheet" />

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.min.css" />

  <!-- CSS STYLES -->
  <link rel="stylesheet" href="css/animate.css" />
  <link rel="stylesheet" href="css/magnific-popup.css" />
  <link rel="stylesheet" href="css/splitting.css" />
  <link rel="stylesheet" href="css/swiper.css" />
  <link rel="stylesheet" href="css/main.css" />

  <!--[if lt IE 9]>
      <script src="http://css3-mediaqueries-js.googlecode.com/svn/trunk/css3-mediaqueries.js"></script>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

  <!-- Favicon -->
  <link rel="shortcut icon" href="favicon.png" type="image/x-icon" />
  <link rel="icon" href="favicon.png" type="image/x-icon" />
</head>

<body>
  <div class="page">
    <!-- Preloader -->
    <div class="preloader">
      <div class="centrize full-width">
        <div class="vertical-center">
          <div class="spinner"></div>
        </div>
      </div>
    </div>

    <!-- Header -->
    <header class="header">
      <!-- Navbar -->
      <div class="navbar">
        <!-- logo -->
        <div class="logo">
          <a href="index.php"><img src="logo-white.jpg" alt="" /></a>
        </div>

        <div class="submit" data-animate="active" style="visibility: visible">
          <a href="register.php" class="btn"> Get Started </a>
        </div>

        <!-- menu btn -->
        <a href="#" class="menu-btn full"><span></span></a>
      </div>

      <!-- Menu Full Overlay -->
      <div class="menu-full-overlay">
        <div class="menu-full-container">
          <div class="container">
            <div class="row">
              <div class="col-xs-12 col-sm-12 col-md-12 col-lg-7 offset-1">
                <!-- menu full -->
                <div class="menu-full">
                  <ul>
                    <li>
                      <a href="register.php" class="splitting-text-anim-2" data-splitting="chars">home</a>
                    </li>
                    <li>
                      <a href="homepage.php" class="splitting-text-anim-2" data-splitting="chars">about</a>
                    </li>
                    <li>
                      <a href="contacts.html" class="splitting-text-anim-2" data-splitting="chars">contact</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </header>

    <!-- Wrapper -->
    <div class="wrapper">
      <!-- Section Main Slider -->
      <div class="section main-slider" data-dispimgpath="images/pointilize.jpg">
        <div class="swiper-container">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <!-- image -->
              <div class="slide">
                <img src="images/started_slide1.jpg" class="main-slide-item__image" alt="" />
              </div>

              <!-- slide titles -->
              <div class="slide-titles">
                <div class="container">
                  <div class="row">
                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                      <!-- title -->
                      <div class="titles">
                        <div class="label splitting-text-anim-1" data-splitting></div>
                        <div class="subtitle splitting-text-anim-1" data-splitting>
                          Online
                        </div>
                        <div class="title">
                          <div class="title-inner splitting-text-anim-2" data-splitting>
                           Production Analysis<br />
                            <strong>System.</strong>
                          </div>
                          <span class="author-text splitting-text-anim-1" data-splitting>ABSA</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="view-btn">
                  <a href="login.php" data-splitting class="splitting-text-anim-1">Login</a>
                </div>
              </div>
            </div>
          </div>

          <!-- navigation -->
          <div class="swiper-buttons">
            <div class="swiper-button-prev scene-nav scene-nav--prev"></div>
            <div class="swiper-button-next scene-nav scene-nav--next"></div>
          </div>
        </div>

        <!-- slides -->
        <div class="canvas main-slider-items__image"></div>
      </div>
    </div>
  </div>

  <!-- cursor -->
  <div class="cursor"></div>

  <!-- Scripts -->
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.bundle.min.js"></script>
  <script src="js/jquery.validate.min.js"></script>
  <script src="js/swiper.min.js"></script>
  <script src="js/splitting.min.js"></script>
  <script src="js/TweenMax.min.js"></script>
  <script src="js/pixi.min.js"></script>
  <script src="js/cursor.js"></script>
  <script src="js/magnific-popup.js"></script>
  <script src="js/imagesloaded.pkgd.js"></script>
  <script src="js/isotope.pkgd.js"></script>
  <script src="js/jquery.scrolla.js"></script>
  <script src="js/skrollr.js"></script>
  <script src="js/main-slider.js"></script>
  <script src="js/full-slider.js"></script>
  <script src="js/half-slider.js"></script>
  <script src="js/ex-slider.js"></script>
  <script src="js/hero-started.js"></script>
  <script src="js/script.js"></script>
  <!--<script src="js/lazysizes.min.js" async=""></script>
	<script>
		/*Lazy*/
		document.addEventListener('lazybeforeunveil', function(e){
			var bg = e.target.getAttribute('data-bg');
			if(bg){
				e.target.style.backgroundImage = 'url(' + bg + ')';
			}
		});
	</script>-->
</body>

</html>