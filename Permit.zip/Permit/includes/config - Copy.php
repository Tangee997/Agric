<?php

define('DB_HOST', '	sql204.epizy.com');
define('DB_USER', 'epiz_30958396');
define('DB_PASS', 'WUmTbzfN6vH');
define('DB_NAME', 'epiz_30958396_permit');

$conn = mysqli_connect('sql204.epizy.com', 'epiz_30958396', 'WUmTbzfN6vH', 'epiz_30958396_permit') or die(mysqli_error());

// Establish database connection.
try {
    $dbh = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_NAME, DB_USER, DB_PASS, array(PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES 'utf8'"));
} catch (PDOException $e) {
    exit("Error: " . $e->getMessage());
}
