<!DOCTYPE html>
<html lang="en">

<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet"/>
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Sofia&effect=fire">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<link href='https://fonts.googleapis.com/css?family=Merienda One' rel='stylesheet'>
<link href='https://fonts.googleapis.com/css?family=Metal' rel='stylesheet'>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">

<body style="background-color:powderblue;" >

<style>
#per{
	padding-left: 100px;
}
</style>
</head>
 <title>Elite Minds Agri-ABSA</title>
 </head>
 
 <body>
 <header>
 
 <nav class="navbar navbar-expand-sm navbar-dark bg-black">
  <div class="container-fluid">
    <a class="navbar-brand" href="menu"></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mynavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="mynavbar">
      <ul class="navbar-nav me-auto">
	  
	   <li class="nav-item">
          <a class="nav-link" href="index.php">HOME</a>
        </li>
        <li class="nav-item" >
          <a class="nav-link" href="Enrollment.html">TRENDING NEWS</a>
        </li>
       
      </ul>
	  
	  <a href="#" class="fa fa-facebook"></a><br>
	  <br>
      <a href="#" class="fa fa-instagram"></a><br>
      <br>
      <a href="#" class="fa fa-twitter"></a>
      <br>


	  
      <form class="d-flex">
        <input class="form-control me-2" type="text" placeholder="">
        <button class="btn btn-primary" type="button">Search</button>
      </form>
    </div>
  </div>
</nav>
 

 </header>
 
 
 <div class="container-fluid mt-5">
     <div class="col-sm-12" style="text-color= black"; font-family: 'Sofia', sans-serif;">
        <h1 style="text-align:center;">HORTICULTURE FARMING</h1>
     </div>
 </div>
 <br>
 <br>
 
</div>
 <br>
 <br>
 
  <div class="container-fluid mt-5">
 <div class="row">
  <div class="col-sm-6 col-2"><img class="img-fluid" id= "per"src="images/vegetable.jpg" style="width:90%; height:"400px"></div>
  <div class="col-sm-6 col-10" style="background-color: clear;">
 <p > The Agriculture sector of Botswana has experienced a steady decline in its contribution</p>
<p >to GDP over past 50 years. The poor performance of the sector, therefore, represents an added</p>
<p >challenge to the fight against poverty. This training needs analysis is carried out to identify the</p>
<p >potential areas of capacity building in agricultural sector of Botswana which would in turn,</p>
<p >contribute to revitalize the agricultural production of the country. Extensive literature review</p>
<p >disclosed that skills of extension workers are low in the areas of forestry production; interpersonal</p>
<p >communication skills; practical farm skills; organizing effective field days; mobilizing people to</p>
<p >form groups; conducting need assessment surveys; organizing effective field trips and farm</p>
<p >walks; crop protection and pest control; fruit production and planning; and setting up result</p>
<p >demonstrations. </p>
   
  </div>
 </div>
 </div>
 
 
   <div class="container-fluid mt-5">
 <div class="row">
  <div class="col-sm-6 col-6">Tuli Block is a completely self funded horticulture farming built from a passion,</p>
  <p>some elbow grease and a little knowhow. The grow crops and sell them to businesess in need of their services.</p>
  <p>They have workers for every type of work that is available in the farm, for example packaging team.</p>
  <p>The National Master Plan for Agricultural Development alsoidentified vegetable production as one of the priority</p>
  <p>areas with potential for development in Botswana. Such potentials are exploited through capacity </p>
  <p>development program of agricultural sector of the country. Generally, agriculture needs due consideration</p>
  <p>for fighting poverty particularly, in the rural areas. Likewise, the gap between production and consumption of</p>
  <p>agriculture products in the country will be narrowed. For its effect, it needs to capacitate extension workers</p>
  <p>through in-service training which is the principal intervention mechanisms for filling the training gaps that </p>
  <p>are identified</p>
​

</div>
  <div class="col-sm-6 col-6" style="background-color: clear;"><img class="img-fluid" src="images/carrot.jpg" style="width:90%; height:400px"><br>
  <br><br>
 
  </div>
 </div>
 </div> 
<br>
<br>
<br>

 <p> Crop production also continues to experience limits on its growth posed by
recurring drought, limited skills, and inadequate use of improved technology. Addressing the
identified gaps is very useful for agricultural development which, in turn, contributes to poverty
reduction program of the country. </p>
<br>
<br>

 
 <div class="container-fluid mt-3">
 <div class="row">
 <div class="col-sm-1"></div>
 <!-- Carousel -->
<div id="demo" class="col-sm-10 carousel slide" data-bs-ride="carousel">
 <!-- The slideshow/carousel -->
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="images/tomato2.jpg" alt="" class="rounded " style="width:100%; height:500px" >
      <div class="carousel-caption">
	  <h1 style="color:blue">FARMERS ARE OUR FOCUS.</h1>
       
      </div>
    </div>
    <div class="carousel-item">
      <img src="images/workers.jpg" alt="" class="d-block" style="width:100%; height:500px">
      <div class="carousel-caption">
        <h1 style="color:red">FARMERS ARE OUR FOCUS.</h1>
        
      </div> 
    </div>
    <div class="carousel-item">
      <img src="images/carrot.jpg" alt="" class="rounded" style="width:100%; height:500px">
      <div class="carousel-caption">
        <h1 style="color:blue">FARMERS ARE OUR FOCUS.</h1>
       
      </div>  
    </div>
	<div class="carousel-item">
      <img src="images/tractor.jpg" alt="" class="d-block" style="width:100%; height:500px">
      <div class="carousel-caption">
        <h1 style="color:white" >FARMERS ARE OUR FOCUS.</h1>
       
      </div>  
    </div>
  </div>
  
  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>
 <div class="col-sm-1"></div>
</div>
 </div>
 
  <div class="container-fluid mt-5">
 <div class="row">
  <div class="col-sm-3 col-2" style="background-color: cyan;"></div>
 
 
 
 
 <h4 style="color:blue ; font-family: 'Metal;"><h4>
 
  <div class="container-fluid mt-5">
 <div class="row">
  <div class="col-sm-6 col-2"><img class="img-fluid" src="images/Laptop.png" style="width:90%; height:400px""></div>
  <div class="col-sm-6 col-10" style="background-color: clear;"><br>
  <br><br>
  <p style="color:black; font-family: Merienda One;">
 Online Crops Production Analysis management System</p>
   
  </div>
 
 
 <div class="container mt-5">
 <div class= "row">
<div class="col-sm-6">
<p> </p>
</div>
 <div class="col-sm-6">
  <p></p>
 </div>
 </div>
</div>



</body>

<br>
<br>
<br>
<footer>

<div class="container-fluid mt-5">
 <div class="row">
  <div class="col-sm-4 col-4"><img class="img-fluid" src="images/absa1.png" style="width:50%; height:100px"></div>
  <div class="col-sm-4 col-4"><img class="img-fluid" src="images/elite.jpg" style="width:50%; height:100px"></div>
  <div class="col-sm-4 col-4"><img class="img-fluid" src="images/temo.png" style="width:50%; height:100px"></div>
 <br><br>
 </div>
<p>© 2022 ELITE MINDS ABSA-HACKATHON. All Rights Reserved.</p>
</footer>

</html>
