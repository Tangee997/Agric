<div class="footer-wrap pd-20 mb-20 card-box">
	Production Analysis <a href="#" target="_blank"><span>developed by </span>Elite Minds</a>
</div>