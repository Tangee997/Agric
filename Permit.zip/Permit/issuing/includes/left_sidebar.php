<div class="left-side-bar">
	<div class="brand-logo">
		<a href="#">
			<p>Agri Portal</p>
			<img src="../vendors/images/.png" alt="" class="dark-logo">
			<img src="../vendors/images/.png" alt="" class="light-logo">
		</a>
		<div class="close-sidebar" data-toggle="left-sidebar-close">
			<i class="ion-close-round"></i>
		</div>
	</div>
	<div class="menu-block customscroll">
		<div class="sidebar-menu">
			<ul id="accordion-menu">
				<li class="dropdown">
					<a href="index.php" class="dropdown-toggle no-arrow">
						<span class="micon dw dw-house-1"></span><span class="mtext">Dashboard</span>
					</a>

				</li>
				<li class="dropdown">
					<a href="javascript:;" class="dropdown-toggle">
						<span class="micon dw dw-apartment"></span><span class="mtext"> Bookkeeping </span>
					</a>
					<ul class="submenu">

						<li><a href="newexport.php">Farm tasks</li>
						
					</ul>
				</li>

				<li class="dropdown">
					<a href="javascript:;" class="dropdown-toggle">
						<span class="micon dw dw-apartment"></span><span class="mtext">  Customer Details </span>
					</a>
					<ul class="submenu">

						<li><a href="newimport.php">Orders</a></li>
					</ul>
				</li>


				

				<li class="dropdown">
					<a href="javascript:;" class="dropdown-toggle">
						<span class="micon dw dw-apartment"></span><span class="mtext"> Business Profiles </span>
					</a>
					<ul class="submenu">

						<li><a href="newprofiles.php">Customers</a></li>
						<li><a href="approvedprofiles.php">Approved Applications </a></li>
						<li><a href="rejectedprofiles.php">Rejected Applications</a></li>
						<li><a href="allprofiles.php">All Applications</a></li>
					</ul>
				</li>






			</ul>
		</div>
	</div>
</div>