<?php error_reporting(0); ?>
<?php include('includes/header.php') ?>
<?php include('../includes/session.php') ?>

<?php
// code for update the read notification status
$isread = 1;
$did = intval($_GET['exportid']);
date_default_timezone_set('Africa/Gaborone');
$admremarkdate = date('Y-m-d G:i:s ', strtotime("now"));
$sql = "update formb set isread=:isread where id=:did";
$query = $dbh->prepare($sql);
$query->bindParam(':isread', $isread, PDO::PARAM_STR);
$query->bindParam(':did', $did, PDO::PARAM_STR);
$query->execute();

// code for action taken on leave
if (isset($_POST['update'])) {
    $did = intval($_GET['exportid']);
    $description = $_POST['description'];
    $astatus = $_POST['astatus'];




    $reg_remarks = 'Export Permit was Rejected. Registra/Registry will not see it';
    $reg_status = 2;
    date_default_timezone_set('Africa/Gaborone');
    $admremarkdate = date('Y-m-d G:i:s ', strtotime("now"));

    if ($astatus === '2') {
        $result = mysqli_query($conn, "update formb,users set formb.AdminRemark='$description',formb.astatus='$astatus',formb.AdminRemarkDate='$admremarkdate', formb.registra_remarks = '$reg_remarks', formb.cstatus = '$reg_status' where formb.id = users.id AND formb.id='$did'");

        if ($result) {
            echo "<script>alert('Permit updated Successfully');</script>";
        } else {
            die(mysqli_error());
        }
    } elseif ($astatus === '1') {
        $result = mysqli_query($conn, "update formb, users set formb.AdminRemark='$description',formb.astatus='$astatus',formb.AdminRemarkDate='$admremarkdate' where formb.id = users.id AND formb.id='$did'");

        if ($result) {
            echo "<script>alert('Permit updated Successfully');</script>";
        } else {
            die(mysqli_error());
        }
    }
}



?>

<style>
    input[type="text"] {
        font-size: 16px;
        color: #0f0d1b;
        font-family: Verdana, Helvetica;
    }

    .btn-outline:hover {
        color: #fff;
        background-color: #524d7d;
        border-color: #524d7d;
    }

    textarea {
        font-size: 16px;
        color: #0f0d1b;
        font-family: Verdana, Helvetica;
    }

    textarea.text_area {
        height: 8em;
        font-size: 16px;
        color: #0f0d1b;
        font-family: Verdana, Helvetica;
    }
</style>

<body>
    <div class="pre-loader">
        <div class="pre-loader-box">
            <div class="loader-logo"><img src="../vendors/images/deskapp-logo-svg.png" alt=""></div>
            <div class='loader-progress' id="progress_div">
                <div class='bar' id='bar1'></div>
            </div>
            <div class='percent' id='percent1'>0%</div>
            <div class="loading-text">
                Loading...
            </div>
        </div>
    </div>

    <?php include('includes/navbar.php') ?>

    <?php include('includes/right_sidebar.php') ?>

    <?php include('includes/left_sidebar.php') ?>

    <div class="mobile-menu-overlay"></div>

    <div class="main-container">
        <div class="pd-ltr-20">
            <div class="min-height-200px">
                <div class="page-header">
                    <div class="row">
                        <div class="col-md-6 col-sm-12">
                            <div class="title">
                                <h4>EXPORT PERMIT DETAILS</h4>
                            </div>
                            <nav aria-label="breadcrumb" role="navigation">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="admin_dashboard.php">Home</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Permit</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>

                <div class="pd-20 card-box mb-30">
                    <div class="clearfix">
                        <div class="pull-left">
                            <h4 class="text-blue h4">Permit Details</h4>
                            <p class="mb-20"></p>
                        </div>
                    </div>
                    <form method="post" action="">

                        <?php
                        if (!isset($_GET['exportid']) && empty($_GET['exportid'])) {
                            // header('Location: index.php');
                        } else {

                            $lid = intval($_GET['exportid']);
                            $sql = "SELECT formb.id as lid,users.name,users.surname,users.id,users.gender,users.cell,users.email,formb.portexit,formb.regtruck,formb.submission,formb.descrip,formb.quantity,formb.value,formb.exportto,formb.astatus,formb.AdminRemark,formb.cstatus,formb.registra_remarks,formb.AdminRemarkDate from formb join users on formb.id=users.id where formb.id=:lid";
                            $query = $dbh->prepare($sql);
                            $query->bindParam(':lid', $lid, PDO::PARAM_STR);
                            $query->execute();
                            $results = $query->fetchAll(PDO::FETCH_OBJ);
                            $cnt = 1;
                            if ($query->rowCount() > 0) {
                                foreach ($results as $result) {
                        ?>

                                    <div class="row">
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Full Name</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo htmlentities($result->name . " " . $result->surname); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Email Address</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-info" readonly value="<?php echo htmlentities($result->email); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Gender</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-success" readonly value="<?php echo htmlentities($result->gender); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Phone Number</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo htmlentities($result->cell); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Port Exit</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-info" readonly value="<?php echo htmlentities($result->portexit); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-4 col-sm-12">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Applied Date</b></label>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-success" readonly value="<?php echo htmlentities($result->submission); ?>">
                                            </div>
                                        </div>




                                    </div>
                                    <div class="form-group row">
                                        <label style="font-size:16px;" class="col-sm-12 col-md-2 col-form-label"><b> Reason</b></label>
                                        <div class="col-sm-12 col-md-10">
                                            <textarea name="" class="form-control text_area" readonly type="text"><?php echo htmlentities($result->descrip); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label style="font-size:16px;" class="col-sm-12 col-md-2 col-form-label"><b>Issuing Officer Remarks</b></label>
                                        <div class="col-sm-12 col-md-10">
                                            <?php
                                            if ($result->AdminRemark == "") : ?>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Waiting for Approval"; ?>">
                                            <?php else : ?>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo htmlentities($result->AdminRemark); ?>">
                                            <?php endif ?>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label style="font-size:16px;" class="col-sm-12 col-md-2 col-form-label"><b>Reg. Remarks</b></label>
                                        <div class="col-sm-12 col-md-10">
                                            <?php
                                            if ($result->registra_remarks == "") : ?>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Waiting for Approval"; ?>">
                                            <?php else : ?>
                                                <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo htmlentities($result->registra_remarks); ?>">
                                            <?php endif ?>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Action Taken Date</b></label>
                                                <?php
                                                if ($result->AdminRemarkDate == "") : ?>
                                                    <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "NA"; ?>">
                                                <?php else : ?>
                                                    <input type="text" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo htmlentities($result->AdminRemarkDate); ?>">
                                                <?php endif ?>

                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b> Status From Issuing Officer</b></label>
                                                <?php $stats = $result->astatus; ?>
                                                <?php
                                                if ($stats == 1) : ?>
                                                    <input type="text" style="color: green;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Approved"; ?>">
                                                <?php
                                                elseif ($stats == 2) : ?>
                                                    <input type="text" style="color: red; font-size: 16px;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Rejected"; ?>">
                                                <?php
                                                else : ?>
                                                    <input type="text" style="color: blue;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Pending"; ?>">
                                                <?php endif ?>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="form-group">
                                                <label style="font-size:16px;"><b>Authorising Status</b></label>
                                                <?php $ad_stats = $result->cstatus; ?>
                                                <?php
                                                if ($ad_stats == 1) : ?>
                                                    <input type="text" style="color: green;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Approved"; ?>">
                                                <?php
                                                elseif ($ad_stats == 2) : ?>
                                                    <input type="text" style="color: red; font-size: 16px;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Rejected"; ?>">
                                                <?php
                                                else : ?>
                                                    <input type="text" style="color: blue;" class="selectpicker form-control" data-style="btn-outline-primary" readonly value="<?php echo "Pending"; ?>">
                                                <?php endif ?>
                                            </div>
                                        </div>

                                        <?php
                                        if (($stats == 0 and $ad_stats == 0) or ($stats == 2 and $ad_stats == 0) or ($stats == 2 and $ad_stats == 2)) {

                                        ?>
                                            <div class="col-md-3">
                                                <div class="form-group">
                                                    <label style="font-size:16px;"><b></b></label>
                                                    <div class="modal-footer justify-content-center">
                                                        <button class="btn btn-primary" id="action_take" data-toggle="modal" data-target="#success-modal">Take&nbsp;Action</button>
                                                    </div>
                                                </div>
                                            </div>

                                            <form name="adminaction" method="post">
                                                <div class="modal fade" id="success-modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-body text-center font-18">
                                                                <h4 class="mb-20">Permit take action</h4>
                                                                <select name="astatus" required class="custom-select form-control">
                                                                    <option value="">Choose your option</option>
                                                                    <option value="1">Approved</option>
                                                                    <option value="2">Rejected</option>
                                                                </select>

                                                                <div class="form-group">
                                                                    <label></label>
                                                                    <textarea id="textarea1" name="description" class="form-control" required placeholder="Description" length="300" maxlength="300"></textarea>
                                                                </div>
                                                            </div>
                                                            <div class="modal-footer justify-content-center">
                                                                <input type="submit" class="btn btn-primary" name="update" value="Submit">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </form>

                                        <?php } ?>
                                    </div>

                        <?php $cnt++;
                                }
                            }
                        } ?>
                    </form>
                </div>

            </div>

            <?php include('includes/footer.php'); ?>
        </div>
    </div>
    <!-- js -->

    <?php include('includes/scripts.php') ?>
</body>

</html>