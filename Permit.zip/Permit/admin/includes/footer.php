<div class="footer-wrap pd-20 mb-20 card-box">
	PRODUCTION ANALYSIS MANAGEMENT SYSTEM<a href="#" target="_blank"><span>developed by </span>Elite Minds</a>
</div>