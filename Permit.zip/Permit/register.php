


<?php

session_start();
error_reporting(0);
include('includes/config.php'); ?>
<?php
if (isset($_POST['register'])) {

  $name = $_POST['name'];
  $surname = $_POST['surname'];
  $omang = $_POST['omang'];
  $cell = $_POST['cell'];


  $email = $_POST['email'];
  $password = md5($_POST['password']);

  $role = 'client';



  $query = mysqli_query($conn, "select * from users where email = '$email'") or die(mysqli_error());
  $count = mysqli_num_rows($query);

  if ($count > 0) { ?>
    <script>
      alert('Email Already Exist');
    </script>
  <?php
  } else {
    mysqli_query($conn, "INSERT INTO users(name,surname,omang,cell,email,password,role) VALUES('$name','$surnamename','$omang','$cell','$email','$password','$role')         
		") or die(mysqli_error()); ?>
    <script>
      alert('Registered Successfully  ');
    </script>;
    <script>
      window.location = "login.php";
    </script>
<?php   }
}

?>




<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Register - Production Analysis Management Hackathon - ABSAHACKTHON</title>
    <link rel="shortcut icon" href="favicon.png" />
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC"
      crossorigin="anonymous"
    />
    <link rel="stylesheet" href="fonts/flaticon.css" />
    <link
      href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap"
      rel="stylesheet"
    />
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/style-2.css" />
  </head>
  <body>
    <section class="fxt-template-animation fxt-template-layout25">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6 col-12 fxt-bg-gradient">
            <div class="fxt-header">
              <div class="fxt-top-content">
                <div class="fxt-transformY-50 fxt-transition-delay-1">
                  <a href="login.php" class="fxt-logo"
                    ><img src="images/Absa2.jpg" alt="Logo" width="150"
                  /></a>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-2">
                  <h1>Welcome To Absa Hackathon</h1>
                </div>
                <div class="fxt-transformY-50 fxt-transition-delay-3">
                  <p>Production Analysis Management portal</p>
                </div>
              </div>
              <div class="fxt-bottom-content">
                <div class="fxt-transformY-50 fxt-transition-delay-11">
                  <p>
                    Already have an account?<a
                      href="login.php"
                      class="switcher-text inline-text"
                      >Login</a
                    >
                  </p>
                </div>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-12 fxt-bg-color">
            <div class="fxt-content">
              <div class="fxt-form">
                <div class="fxt-transformY-50 fxt-transition-delay-12">
                  <h2>Create an account</h2>
                </div>
                <form method="POST">
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="text"
                        id="name"
                        class="form-control"
                        name="name"
                        placeholder="Name"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="text"
                        id="surname"
                        class="form-control"
                        name="surname"
                        placeholder="Surname"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="text"
                        id="omang"
                        class="form-control"
                        name="omang"
                        placeholder="Omang"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="text"
                        id="cell"
                        class="form-control"
                        name="cell"
                        placeholder="Cell Number"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-14">
                      <input
                        type="email"
                        class="form-control"
                        name="email"
                        placeholder="Email Address"
                        required="required"
                      />
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-15">
                      <input
                        id="password"
                        type="password"
                        class="form-control"
                        name="password"
                        placeholder="********"
                        required="required"
                      />
                      <i
                        toggle="#password"
                        class="fa fa-fw fa-eye toggle-password field-icon"
                      ></i>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="fxt-transformY-50 fxt-transition-delay-17">
                      <button type="submit" class="fxt-btn-fill" name="register">
                        Register
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM"
      crossorigin="anonymous"
    ></script>
    <!-- Imagesloaded js -->
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <!-- Validator js -->
    <script src="js/validator.min.js"></script>
    <!-- Custom Js -->
    <script src="js/main.js"></script>
  </body>
</html>
